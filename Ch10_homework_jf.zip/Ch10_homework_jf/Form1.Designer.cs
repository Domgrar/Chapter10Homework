﻿namespace Ch10_homework_jf
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioHockey = new System.Windows.Forms.RadioButton();
            this.radioSoccer = new System.Windows.Forms.RadioButton();
            this.radioFootball = new System.Windows.Forms.RadioButton();
            this.radioBaseball = new System.Windows.Forms.RadioButton();
            this.radioBasketball = new System.Windows.Forms.RadioButton();
            this.buttonSignUp = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radioHockey
            // 
            this.radioHockey.AutoSize = true;
            this.radioHockey.Location = new System.Drawing.Point(30, 56);
            this.radioHockey.Name = "radioHockey";
            this.radioHockey.Size = new System.Drawing.Size(62, 17);
            this.radioHockey.TabIndex = 0;
            this.radioHockey.TabStop = true;
            this.radioHockey.Text = "Hockey";
            this.radioHockey.UseVisualStyleBackColor = true;
            this.radioHockey.CheckedChanged += new System.EventHandler(this.radioHockey_CheckedChanged);
            // 
            // radioSoccer
            // 
            this.radioSoccer.AutoSize = true;
            this.radioSoccer.Location = new System.Drawing.Point(30, 115);
            this.radioSoccer.Name = "radioSoccer";
            this.radioSoccer.Size = new System.Drawing.Size(59, 17);
            this.radioSoccer.TabIndex = 1;
            this.radioSoccer.TabStop = true;
            this.radioSoccer.Text = "Soccer";
            this.radioSoccer.UseVisualStyleBackColor = true;
            // 
            // radioFootball
            // 
            this.radioFootball.AutoSize = true;
            this.radioFootball.Location = new System.Drawing.Point(30, 179);
            this.radioFootball.Name = "radioFootball";
            this.radioFootball.Size = new System.Drawing.Size(62, 17);
            this.radioFootball.TabIndex = 2;
            this.radioFootball.TabStop = true;
            this.radioFootball.Text = "Football";
            this.radioFootball.UseVisualStyleBackColor = true;
            // 
            // radioBaseball
            // 
            this.radioBaseball.AutoSize = true;
            this.radioBaseball.Location = new System.Drawing.Point(30, 250);
            this.radioBaseball.Name = "radioBaseball";
            this.radioBaseball.Size = new System.Drawing.Size(65, 17);
            this.radioBaseball.TabIndex = 3;
            this.radioBaseball.TabStop = true;
            this.radioBaseball.Text = "Baseball";
            this.radioBaseball.UseVisualStyleBackColor = true;
            // 
            // radioBasketball
            // 
            this.radioBasketball.AutoSize = true;
            this.radioBasketball.Location = new System.Drawing.Point(30, 318);
            this.radioBasketball.Name = "radioBasketball";
            this.radioBasketball.Size = new System.Drawing.Size(74, 17);
            this.radioBasketball.TabIndex = 4;
            this.radioBasketball.TabStop = true;
            this.radioBasketball.Text = "Basketball";
            this.radioBasketball.UseVisualStyleBackColor = true;
            // 
            // buttonSignUp
            // 
            this.buttonSignUp.Location = new System.Drawing.Point(260, 315);
            this.buttonSignUp.Name = "buttonSignUp";
            this.buttonSignUp.Size = new System.Drawing.Size(150, 41);
            this.buttonSignUp.TabIndex = 5;
            this.buttonSignUp.Text = "Click me to sign up!";
            this.buttonSignUp.UseVisualStyleBackColor = true;
            this.buttonSignUp.Click += new System.EventHandler(this.buttonSignUp_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(138, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(301, 295);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 368);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonSignUp);
            this.Controls.Add(this.radioBasketball);
            this.Controls.Add(this.radioBaseball);
            this.Controls.Add(this.radioFootball);
            this.Controls.Add(this.radioSoccer);
            this.Controls.Add(this.radioHockey);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioHockey;
        private System.Windows.Forms.RadioButton radioSoccer;
        private System.Windows.Forms.RadioButton radioFootball;
        private System.Windows.Forms.RadioButton radioBaseball;
        private System.Windows.Forms.RadioButton radioBasketball;
        private System.Windows.Forms.Button buttonSignUp;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

