﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ch10_homework_jf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //Create a radio array to hold all our radio buttons after initialization
           var radioButtonArray = new RadioButton[] { radioHockey, radioSoccer, radioFootball, radioBaseball, radioBasketball, };

            // Go through our radio buttons and assign a tag number and 
            // add the .CheckedChanged to the event handler below
            for(int i = 0; i < radioButtonArray.Length; i++)
            {
                radioButtonArray[i].Tag = i;
                radioButtonArray[i].CheckedChanged += new EventHandler(radioButtons_CheckedChanged);
            }
        }

        //Event handler method for any of the radiobuttons.CheckedChanged event
        private void radioButtons_CheckedChanged(object sender, EventArgs e)
        {
            //Assign selectedButton as the sender
            RadioButton selectedButton = sender as RadioButton;

            //As long as the button isn't null
            if(selectedButton != null)
            {
                //Get the tag and call preform action based on the tag
                int buttonID = (int)selectedButton.Tag;
                PreformAction(buttonID);
            }
        }

        //Method to assign pictureBox image based on what radiobutton is selected
        public void PreformAction(int buttonID)
        {
            switch (buttonID)
            {
                case 0: // Hockey
                    pictureBox1.Image = Properties.Resources.Hockey;
                    break;

                case 1: // Soccer
                    pictureBox1.Image = Properties.Resources.soccer;
                    break;


                case 2: // Football
                    pictureBox1.Image = Properties.Resources.football;
                    break;

                case 3: // Baseball
                    pictureBox1.Image = Properties.Resources.baseball;
                    break;

                case 4: // Basketball
                    pictureBox1.Image = Properties.Resources.basketball;
                    break;

                

            }
        }


        private void radioHockey_CheckedChanged(object sender, EventArgs e)
        {

        }

        //On sign up button click
        //Finds which radiobutton is checked and displays a message based on that
        private void buttonSignUp_Click(object sender, EventArgs e)
        {
            if (radioHockey.Checked)
            {
                MessageBox.Show("Remember your pads!");
            }else if (radioSoccer.Checked)
            {
                MessageBox.Show("Bring your own soccer ball.");
            }else if (radioFootball.Checked)
            {
                MessageBox.Show("Buy a helmet before practice.");
            }else if (radioBaseball.Checked)
            {
                MessageBox.Show("Remember to bring sunscreen.");
            }
            else
            {
                MessageBox.Show("Must bring your own basketball to first practice.");
            }

        }
    }
}
